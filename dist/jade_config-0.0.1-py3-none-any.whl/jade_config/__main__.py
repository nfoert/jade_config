# Standard library imports
import sys

# Reader imports
import config
from config import test

def main() -> None:
    #Do all the logic stuff
    test()

if __name__ == "__main__":
    main()