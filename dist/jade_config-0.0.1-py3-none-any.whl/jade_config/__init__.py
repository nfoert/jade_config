"""
----- Jade Config -----
A python package to quickly and easily make configs, 
or other things that your program needs to remember.
"""
# Standard library imports
import shelve


# Version of jade-config package
__version__ = "0.0.1"

# Thanks to https://realpython.com/pypi-publish-python-package/#prepare-your-package-for-publication for help on this