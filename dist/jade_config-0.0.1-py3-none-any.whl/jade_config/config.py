#Do some stuff

def test():
    print("Hello, world!")