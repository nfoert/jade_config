# jade-config
A python package to quickly and easily make configs, or other things that your program needs to remember.

WARNING: Not working yet, just testing the PyPI upload. DON'T DOWNLOAD ME!
